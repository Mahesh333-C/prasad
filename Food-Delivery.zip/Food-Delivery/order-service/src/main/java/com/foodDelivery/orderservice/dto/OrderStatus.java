package com.foodDelivery.orderservice.dto;

public enum OrderStatus{
    ACCEPTED,
    PREPARING,
    DELIVERED
}
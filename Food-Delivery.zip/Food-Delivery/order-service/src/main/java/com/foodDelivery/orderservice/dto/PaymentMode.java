package com.foodDelivery.orderservice.dto;

public enum PaymentMode{
    CASH,
    DEBIT_CARD,
    CREDIT_CARD
}

package com.foodDelivery.paymentservice.dto;

public enum PaymentMode{
    CASH,
    DEBIT_CARD,
    CREDIT_CARD
}

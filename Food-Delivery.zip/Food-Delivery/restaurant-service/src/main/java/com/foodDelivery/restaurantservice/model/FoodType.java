package com.foodDelivery.restaurantservice.model;

public enum FoodType{
    appetizers,
    mainCourse,
    desserts
}

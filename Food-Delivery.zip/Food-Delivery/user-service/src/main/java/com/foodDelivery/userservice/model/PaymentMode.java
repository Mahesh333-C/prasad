package com.foodDelivery.userservice.model;

public enum PaymentMode{
    CASH,
    DEBIT_CARD,
    CREDIT_CARD
}

package com.HiBank.controller;

import com.HiBank.dto.TransactionDetails;
import com.HiBank.model.CardTransaction;
import com.HiBank.service.CardService;
import com.HiBank.service.CardTransactionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/card")
public class CardController
{
  @Autowired
  private CardTransactionService cardTransactionService;
  @Autowired
  private CardService cardService;

  @PreAuthorize("hasAuthority('admin') or hasAuthority('poc') or hasAuthority('standard')")
  @PostMapping("/upload")
  public ResponseEntity<CardTransaction> UploadTransaction(@RequestBody @Valid TransactionDetails transactionDetails, @RequestHeader("Authorization") String authorizationHeader)
  {
    return ResponseEntity.ok(cardTransactionService.uploadTransaction(transactionDetails, authorizationHeader));
  }
}

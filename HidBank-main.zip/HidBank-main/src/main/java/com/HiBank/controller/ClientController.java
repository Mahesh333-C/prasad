package com.HiBank.controller;

import com.HiBank.exception.BadRequestException;
import com.HiBank.exception.ForbiddenException;
import com.HiBank.model.Client;
import com.HiBank.service.ClientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/client")
@Slf4j
public class ClientController
{
  @Autowired
  private ClientService clientService;

  @PreAuthorize("hasAuthority('admin')")
  @GetMapping
  @Operation(
          summary = "Get all clients",
          responses = @ApiResponse(responseCode = "200", description = "All the clients will be returned"))
  public ResponseEntity<List<Client>> getClients() throws ForbiddenException
  {
      return ResponseEntity.ok(clientService.getAllClients());
  }

  @PreAuthorize("hasAuthority('admin')")
  @PostMapping
  public ResponseEntity<Client> addClient(@RequestBody @Valid Client client) throws Exception
  {
    Client savedClient;
    if (client == null || client.getName() == null)
    {
      log.error("Invalid client details while adding");
      throw new BadRequestException("Invalid Client input");
    }
    else
    {
      try
      {
        log.info("Adding a new client");
        savedClient = clientService.addClient(client);
        log.info("successfully added a new client");
      }
      catch (Exception e)
      {
        log.error("Error while adding a client");
        throw new DataIntegrityViolationException("Client Already exist");
      }
    }
    return ResponseEntity.ok(savedClient);
  }

  @PreAuthorize("hasAuthority('admin')")
  @PutMapping
  public ResponseEntity<Client> updateClient(@RequestBody Client client) throws Exception
  {
    Client updatedClient;
    if (client == null || client.getId() == null)
    {
      log.error("Invalid client details while updating");
      throw new BadRequestException("Invalid Client input");
    }
    else
    {
      try
      {
        log.info("updating a new client");
        updatedClient = clientService.updateClient(client);
        log.info("successfully updated a client");
      }
      catch (Exception e)
      {
        log.error("Error while updating the client");
        throw new Exception();
      }
    }
    return ResponseEntity.ok(updatedClient);
  }

  @PreAuthorize("hasAuthority('admin')")
  @DeleteMapping("/{id}")
  public ResponseEntity<Client> deleteClient(@PathVariable Long id) throws Exception
  {
    Client deletedClient;
    if (id == null)
    {
      log.error("Invalid Client id");
      throw new BadRequestException("Invalid id");
    }
    else
    {
      try
      {
        log.info("Deleting a client");
        deletedClient = clientService.deleteClient(id);
        log.error("Deleted a client successfully");
      }
      catch (Exception e)
      {
        log.error("Error while deleting a role" + e.getMessage());
        throw new Exception("Error while deleting a role");
      }
    }
    return ResponseEntity.ok(deletedClient);
  }
}
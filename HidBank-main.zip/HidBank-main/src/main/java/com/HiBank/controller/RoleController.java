package com.HiBank.controller;

import com.HiBank.exception.BadRequestException;
import com.HiBank.model.Role;
import com.HiBank.repository.RoleRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/role")
@Slf4j
public class RoleController
{
  @Autowired
  RoleRepo roleRepo;
  @PostMapping
  public ResponseEntity<Role> addRole(@RequestBody Role role) throws Exception
  {
    Role savedRole;
    if (role == null)
    {
      log.error("invalid role details");
      throw new BadRequestException("Invalid role");
    }
    else
    {
      try
      {
        savedRole = roleRepo.save(role);
        log.info("successfully saved role details");
      }
      catch (Exception e)
      {
        log.error("error while saving a role");
        throw new Exception("Error while saving a role");
      }
    }
    return ResponseEntity.ok(savedRole);
  }

  @GetMapping
  public ResponseEntity<List<Role>> getRoles()
  {
    return ResponseEntity.ok(roleRepo.findAll());
  }
}
package com.HiBank.controller;

import com.HiBank.dto.UserLogin;
import com.HiBank.service.JwtService;
import com.HiBank.dto.ClientUser;
import com.HiBank.dto.AdminLogin;
import com.HiBank.exception.BadRequestException;
import com.HiBank.exception.ResourceNotFoundException;
import com.HiBank.model.Token;
import com.HiBank.model.Users;
import com.HiBank.service.CardService;
import com.HiBank.service.RoleService;
import com.HiBank.service.UserService;
import io.jsonwebtoken.Claims;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@AllArgsConstructor
@Log4j2
@RequestMapping("/user")
public class UserController
{
  @Autowired
  private UserService userService;
  @Autowired
  private RoleService roleService;
  @Autowired
  private CardService cardService;
  private final JwtService jwtService;
  private final AuthenticationManager authenticationManager;

  @PreAuthorize("hasAuthority('admin') or hasAuthority('poc')")
  @GetMapping("/findAll")
  public ResponseEntity<List<Users>> getUsers(@RequestHeader("Authorization") String authorizationHeader)
  {
    String token = authorizationHeader.replace("Bearer ", "");
    Claims claims = jwtService.getClaims(token);
    if (claims.get("id") == null && userService.getUserRole(jwtService.extractUsername(token)).equals("admin"))
    {
      log.info("logged in user has role admin");
      return ResponseEntity.ok(userService.getAllUsers());
    }
    else
    {
      log.info("logged in user has role admin");
      return ResponseEntity.ok(userService.getAllUsersByClientId(Long.parseLong(claims.get("id").toString())));
    }
  }

  @PreAuthorize("hasAuthority('admin') or hasAuthority('poc')")
  @PostMapping("/register")
  public ResponseEntity<Users> addUser(@RequestBody @Valid ClientUser user, @RequestHeader("Authorization") String authorizationHeader) throws Exception
  {
    if (user == null)
    {
      log.error("user details are invalid");
      throw new BadRequestException("Invalid User input");
    }
    return ResponseEntity.ok(userService.registerUser(user, authorizationHeader));
  }

  @PostMapping("/admin/register")
  public ResponseEntity<Users> addAdmin(@RequestBody @Valid AdminLogin user) throws Exception
  {
    if (user == null)
    {
      log.error("user details are invalid");
      throw new BadRequestException("Invalid User input");
    }
    return ResponseEntity.ok(userService.registerAdmin(user));
  }

  @PreAuthorize("hasAuthority('admin') or hasAuthority('poc')")
  @PutMapping("/{userId}/role/{roleId}")
  public ResponseEntity<Users> assignRole(@PathVariable Long userId, @PathVariable Long roleId)
  {
    return userService.assignRole(userId, roleId);
  }

  @PostMapping("/authenticate")
  public Token authenticateAndGetToken(@RequestBody @Valid UserLogin user)
  {
    try
    {
      log.info("Authenticating the user");
      authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
      String jwtToken;
      if (userService.getUserRole(user.getUsername()).equals("admin"))
      {
        log.info("Authenticated user has role 'admin'");
        jwtToken = jwtService.generateToken(user, true, false);
      }
      else
      {
        if (userService.getUserRole(user.getUsername()).equals("poc"))
        {
          log.info("Authenticated user has role 'poc'");
          jwtToken = jwtService.generateToken(user, false, false);
        }
        else
        {
          log.info("Authenticated user has role 'standard'");
          jwtToken = jwtService.generateToken(user, false, true);
        }
      }
      return Token.builder().token(jwtToken).build();
    }
    catch (Exception e)
    {
      log.error("user name or password entered is wrong");
      throw  new ResourceNotFoundException("user name or password is wrong");
    }
  }

  @PreAuthorize("hasAuthority('admin') or hasAuthority('poc')")
  @DeleteMapping("/{id}")
  public ResponseEntity<Users> deleteUser(@PathVariable Long id, @RequestHeader("Authorization") String authorizationHeader)
  {
    return ResponseEntity.ok(userService.deleteUser(id, authorizationHeader));
  }

  @PreAuthorize("hasAuthority('admin') or hasAuthority('poc')")
  @PutMapping("/assign-card/{id}")
  public ResponseEntity<Users> assignNewCard(@PathVariable Long id, @RequestHeader("Authorization") String authorizationHeader)
  {
    return ResponseEntity.ok(cardService.assignNewCard(id, authorizationHeader));
  }
}
package com.HiBank.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AdminLogin
{
  @NotBlank(message = "username must not empty")
  private String userName;
  @NotBlank(message = "password must not empty")
  private String password;
  @NotBlank(message = "email must not empty")
  private String Email;
}

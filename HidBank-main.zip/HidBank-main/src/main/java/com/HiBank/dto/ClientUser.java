package com.HiBank.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ClientUser
{
  @NotBlank(message = "user name must not empty")
  private String username;
  @NotBlank(message = "password must not empty")
  private String password;
  @NotNull(message = "client id must not empty")
  private Long clientId;
  @NotNull(message = "role id id not empty")
  private Long roleId;
  @NotBlank(message = "email must not empty")
  private String email;
}

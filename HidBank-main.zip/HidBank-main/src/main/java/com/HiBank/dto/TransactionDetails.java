package com.HiBank.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransactionDetails
{
  @NotNull(message = "Card id is required")
  private Long cardId;
  @NotNull(message = "Amount is required")
  private Long amount;
}

package com.HiBank.exception;

public class CardCreationException extends RuntimeException
{
  public CardCreationException() {
    super();
  }

  public CardCreationException(String message) {
    super(message);
  }
}

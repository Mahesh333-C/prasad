package com.HiBank.exception;

public class CardTransactionException extends RuntimeException
{
  public CardTransactionException() {
    super();
  }

  public CardTransactionException(String message) {
    super(message);
  }
}

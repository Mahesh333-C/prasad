package com.HiBank.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Card
{
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Column(unique = true)
  private String number;

  private LocalDateTime issuedDate;

  private LocalDateTime validTill;

  @JsonIgnore
  private Boolean isReported = false;

  private Boolean isValid = true;

  @JsonIgnore
  @ManyToOne
  @JoinColumn(name = "user_id")
  private Users user;

  @JsonIgnore
  @OneToMany(mappedBy = "card", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<CardTransaction> cardTransactions;

  public String getNumber()
  {
    return number.replace(number.substring(5, 9), "****").replace(number.substring(10, 14), "****");
  }
}
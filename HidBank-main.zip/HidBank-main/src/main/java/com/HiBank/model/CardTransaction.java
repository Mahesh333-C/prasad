package com.HiBank.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CardTransaction
{
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long transactionId;

  private Long amount;

  @ManyToOne
  @JoinColumn(name = "card_id")
  private Card card;
}
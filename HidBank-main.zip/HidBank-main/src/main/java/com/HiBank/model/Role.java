package com.HiBank.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.util.List;

@Entity
@Data
public class Role
{

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  private String role;

  @JsonIgnore
  @OneToMany(mappedBy = "role", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<Users> users;
}

package com.HiBank.repository;

import com.HiBank.model.CardTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CardTransactionRepo extends JpaRepository<CardTransaction, Long>
{
  @Query("select c.id, sum(amount) from Client c\n" +
          "join Users u on u.client.id = c.id\n" +
          "join Card cd on cd.user.id = u.id\n" +
          "join CardTransaction CT on CT.card.id = cd.id\n" +
          "group by c.id")
  List<Object[]> findTotalAmountByClient();
}

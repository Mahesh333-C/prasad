package com.HiBank.repository;

import com.HiBank.model.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface UserRepo extends JpaRepository<Users, Long>
{
  public Users findByUserName(String userName);

  @Query("select email from Users\n" +
          "where role.id = (select id from Role where role = 'admin')")
  public List<String> findAdminEmails();
  public List<Users> findAllByIsDeleted(Boolean isDeleted);
  public List<Users> findAllByClientIdAndIsDeleted(Long clientId, Boolean isDeleted);
  @Query("select c.id, c.name, u.email from Users u\n" +
          "join Client c on c.id = u.client.id\n" +
          "where u.role.id in (select id from Role where role = 'poc') and c.isDeleted = 0 and u.isDeleted = false")
  public List<Object[]> findEmailIdOfClientPoc();
}

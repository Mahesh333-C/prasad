package com.HiBank.scheduler;

import com.HiBank.model.Card;
import com.HiBank.repository.CardRepo;
import com.HiBank.repository.CardTransactionRepo;
import com.HiBank.repository.ClientRepo;
import com.HiBank.repository.UserRepo;
import com.HiBank.service.EmailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Component
@Slf4j
public class HiBankJob
{
  @Autowired
  private CardTransactionRepo cardTransactionRepo;
  @Autowired
  private CardRepo cardRepo;
  @Autowired
  private ClientRepo clientRepo;
  @Autowired
  private UserRepo userRepo;
  @Autowired
  private EmailService emailService;
  public HashMap<String, String> clients = new HashMap<>();

  public HashMap<String, List<String>> getPocAndEmails()
  {
    log.info("get poc email function called");
    HashMap<String, List<String>> clientPocEmails = new HashMap<>();
    List<Object[]> ClientPocEmails = userRepo.findEmailIdOfClientPoc();
    log.info("Collected info of all the Clients poc email");
    for (Object[] objArray : ClientPocEmails)
    {
      Long clientId = (Long) objArray[0];
      String email = (String) objArray[2];
      String name = (String) objArray[1];
      clients.put(clientId.toString(), name);
      if (clientPocEmails.containsKey(clientId.toString()))
      {
        clientPocEmails.get(clientId.toString()).add(email);
      }
      else
      {
        ArrayList<String> emails = new ArrayList<>();
        emails.add(email);
        clientPocEmails.put(clientId.toString(), emails);
      }
    }
    log.info("Successfully stored all the client poc email details");
    return clientPocEmails;
  }

  @Scheduled(cron = "0 10 13 15 * *")
  public void CalculateTheSum()
  {
    log.info("Total Sum Cron job started");
    Long totalSummary = 0L;
    log.info("called total amount by client function");
    List<Object[]> clientTotalSummary = cardTransactionRepo.findTotalAmountByClient();
    log.info("successfully stored total amount by client function");
    log.info("called function to get poc and their emails");
    HashMap<String, List<String>> clientPocEmails = getPocAndEmails();
    log.info("successfully stored details of poc and their emails");
    for (Object[] objArray : clientTotalSummary)
    {
      String summary = "This is total summary : \n";
      Long clientId = (Long) objArray[0];
      Long totalAmount = (Long) objArray[1];
      totalSummary += totalAmount;
      summary = String.format(summary, clients.get(clientId.toString()));
      summary += "Total amount is " + totalAmount;
      log.info("Created a summary to send an monthly report to poc's");
      emailService.sendEmail(clientPocEmails.get(clientId.toString()), String.format("Monthly Report of %s", clients.get(clientId.toString())), summary);
      log.info("Successfully sent monthly report to poc's");
    }
    emailService.sendEmail(userRepo.findAdminEmails(), "Monthly Report of Clients", String.format("Total amount across the clients is %s", totalSummary));
    log.info("Successfully sent monthly report to admin");
  }

  @Scheduled(cron = "0 * * * * *")
  public void validateCardExpiry()
  {
    log.info("Card Expiry Cron job started");
    List<Card> validCards = cardRepo.findAllByIsValidAndIsReported(true, false);
    log.info("Successfully fetched all the valid cards");
    for (Card card : validCards)
    {
      long daysUntilExpiry = ChronoUnit.DAYS.between(LocalDate.now(), card.getValidTill());
      if (daysUntilExpiry <= 2)
      {
        log.info(String.format("Card with id : %s, will expire in new two days", card.getId()));
        if (card.getIsReported() == false)
        {
          log.info(String.format("Card with id : %s, is not reported to the user yet", card.getId()));
          emailService.sendEmail(Collections.singletonList(card.getUser().getEmail()), "Card Expiry Reminder", String.format("Dear %s,\nYour card %s is expiring in two days. Please take necessary action.", card.getUser().getUsername(), card.getNumber()));
          log.info("Reminder email sent for " + card.getUser().getEmail());
          card.setIsReported(true);
          log.info("Reported to the user successfully");
        }
      }
      LocalDateTime localDateTime = LocalDateTime.now();
      if (card.getValidTill().isBefore(localDateTime))
      {
        log.info(String.format("Card with id : %s, already expired", card.getId()));
        log.info(String.format("The user : %s having card %s is valid till %s", card.getUser().getUsername(), card.getNumber(), card.getValidTill()));
        card.setIsValid(false);
        log.info("Invalidated the card successfully");
      }
      cardRepo.save(card);
      log.info("Successfully saved all the card details");
    }
  }
}

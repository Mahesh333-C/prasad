package com.HiBank.service;

import com.HiBank.exception.BadRequestException;
import com.HiBank.exception.CardCreationException;
import com.HiBank.exception.ResourceNotFoundException;
import com.HiBank.model.Card;
import com.HiBank.model.Users;
import com.HiBank.repository.UserRepo;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CardService
{
  @Autowired
  UserService userService;
  @Autowired
  JwtService jwtService;
  @Autowired
  UserRepo userRepo;

  public Users assignNewCard(Long userId, String authorizationHeader)
  {
    try
    {
      Users user = userRepo.findById(userId).orElse(null);
      String token = authorizationHeader.replace("Bearer ", "");
      Claims claims = jwtService.getClaims(token);
      if (!claims.get("id").toString().equals(user.getClient().getId().toString()))
      {
        throw new AccessDeniedException("Cannot access other client users");
      }
      if (user == null)
      {
        log.info(String.format("user with id %s not found", userId));
        throw new ResourceNotFoundException(String.format("User with id : %s does not exists", userId));
      }
      if (user.getRole().getRole().equals("poc"))
      {
        throw new BadRequestException("Assigning card to POC is not allowed");
      }
      userService.invalidateExistingCards(user);
      log.info("Invalidated the existing cards successfully");
      Card card = userService.generateCard(user);
      log.info("Generated a new card for user");
      user.getCard().add(card);
      return userRepo.save(user);
    }
    catch (AccessDeniedException e)
    {
      throw new AccessDeniedException("Cannot access other client users");
    }
    catch (Exception e)
    {
      log.error(e.getMessage());
      throw new CardCreationException("Error while assigning a new card");
    }
  }
}
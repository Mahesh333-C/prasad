package com.HiBank.service;

import com.HiBank.dto.TransactionDetails;
import com.HiBank.exception.BadRequestException;
import com.HiBank.exception.CardTransactionException;
import com.HiBank.model.Card;
import com.HiBank.model.CardTransaction;
import com.HiBank.repository.CardRepo;
import com.HiBank.repository.CardTransactionRepo;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CardTransactionService
{
  @Autowired
  private CardTransactionRepo cardTransactionRepo;
  @Autowired
  private CardRepo cardRepo;
  @Autowired
  private JwtService jwtService;
  @Autowired
  private UserService userService;

  public CardTransaction uploadTransaction(TransactionDetails transactionDetails, Card card)
  {
    try
    {
      log.info(String.format("Uploading the transaction for card with id : %s", card.getId()));
      CardTransaction cardTransaction = CardTransaction.builder()
              .amount(transactionDetails.getAmount())
              .card(card)
              .build();
      return cardTransactionRepo.save(cardTransaction);
    }
    catch(Exception e)
    {
      log.error(String.format("Error while uploading the card : %s transaction", card.getId()));
      throw new CardTransactionException("Error while uploading the card transaction");
    }
  }

  public CardTransaction uploadTransaction(TransactionDetails transactionDetails, String authorizationHeader)
  {
    Card card = cardRepo.findByIdAndIsValid(transactionDetails.getCardId(), true);
    if (card == null)
    {
      log.error("Card with id : %s does not exist", transactionDetails.getCardId());
      throw new BadRequestException(String.format("Card with id : %s does not exist", transactionDetails.getCardId()));
    }
    String token = authorizationHeader.replace("Bearer ", "");
    Claims claims = jwtService.getClaims(token);
    log.info("Successfully claimed token and claims");
    if (claims.get("id") == null)
    {
      log.info("User don't have any client associated");
      if (userService.getUserRole(jwtService.extractUsername(token)).equals("admin"))
      {
        log.info("admin user uploading the transaction");
        return uploadTransaction(transactionDetails, card);
      }
      else
      {
        log.error("poc or admin trying to upload transaction with out client association");
        throw new BadRequestException("Invalid Client information");
      }
    }
    else
    {
      if (userService.getUserRole(jwtService.extractUsername(token)).equals("poc"))
      {
        log.info("poc user trying to upload the transaction");
        if (!claims.get("id").toString().equals(userService.getUserById(card.getUser().getId()).getClient().getId().toString()) || card.getIsValid() != true)
        {
          log.error("poc trying to upload the transaction for other client users");
          throw new AccessDeniedException("Access Denied : User do not have permission");
        }
      }
      if (userService.getUserRole(jwtService.extractUsername(token)).equals("standard") && !claims.get("cardId").toString().equals(transactionDetails.getCardId().toString()))
      {
        log.error("standard user card id is not matching");
        throw new AccessDeniedException("Access Denied : User do not have permission");
      }
      return uploadTransaction(transactionDetails, card);
    }
  }
}

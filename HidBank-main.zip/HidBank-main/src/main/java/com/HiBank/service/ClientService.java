package com.HiBank.service;

import com.HiBank.exception.ResourceNotFoundException;
import com.HiBank.model.Client;
import com.HiBank.repository.ClientRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@Slf4j
public class ClientService
{
  @Autowired
  private ClientRepo clientRepo;

  public List<Client> getAllClients()
  {
    List<Client> clients = clientRepo.findByIsDeletedEquals(0);
    log.info("fetched all the clients who are not deleted");
    return clients;
  }

  public Client addClient(Client client)
  {
    return clientRepo.save(client);
  }

  public Client updateClient(Client client)
  {
    Client updatedClient;
    if (clientRepo.findById(client.getId()) == null)
    {
      log.error(String.format("Client with id : %s does not exist", client.getId()));
      throw new ResourceNotFoundException(String.format("Client with id = %s does not exist", client.getId()));
    }
    else
    {
      updatedClient = clientRepo.findById(client.getId()).orElse(null);
      log.info("successfully fetched client details");
      if (client.getName() != null)
      {
        updatedClient.setName(client.getName());
      }
      updatedClient = clientRepo.save(updatedClient);
      log.info("saved updated client details successfully");
    }
    return updatedClient;
  }

  public Client deleteClient(Long id)
  {
    Client deletedClient;
    if (clientRepo.findById(id) == null)
    {
      log.error(String.format("Client with id : %s does not exist", id));
      throw new ResourceNotFoundException(String.format("Client with id = %s does not exist", id));
    }
    else
    {
      deletedClient = clientRepo.findById(id).orElse(null);
      log.info("Successfully fetched client details");
      deletedClient.setIsDeleted(1);
      log.info("soft deleted the user successfully");
      clientRepo.save(deletedClient);
      log.info("saved deleted user details successfully");
    }
    return deletedClient;
  }
}
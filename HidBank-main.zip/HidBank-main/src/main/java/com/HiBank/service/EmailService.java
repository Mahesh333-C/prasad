package com.HiBank.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@Slf4j
public class EmailService
{
  @Autowired
  private JavaMailSender emailSender;

  public void sendEmail(List<String> to, String subject, String text)
  {
    for (String email : to)
    {
      SimpleMailMessage message = new SimpleMailMessage();
      log.info("forming the mail message");
      message.setTo(email);
      message.setSubject(subject);
      message.setText(text);
      emailSender.send(message);
      log.info(String.format("Sent mail to %s successfully", email));
    }
  }
}

package com.HiBank.service;

import com.HiBank.exception.ResourceNotFoundException;
import com.HiBank.model.Role;
import com.HiBank.repository.RoleRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class RoleService
{
  @Autowired
  private RoleRepo roleRepo;

  public Role getRole(Long id)
  {
    Role role = roleRepo.findById(id).orElse(null);
    if (role == null)
    {
      log.info(String.format("Role with id : %s does not exist", id));
      throw new ResourceNotFoundException(String.format("Role with id : %s does not exist", id));
    }
    return role;
  }

  public Role getRoleByRoleName(String name)
  {
    Role role = roleRepo.findByRole(name);
    if (role == null)
    {
      log.info(String.format("Role with name : %s does not exist", name));
      throw new ResourceNotFoundException(String.format("Role with name : %s does not exist", name));
    }
    return role;
  }
}
package com.HiBank.service;

import com.HiBank.dto.ClientUser;
import com.HiBank.dto.AdminLogin;
import com.HiBank.exception.BadRequestException;
import com.HiBank.exception.CardCreationException;
import com.HiBank.exception.ResourceNotFoundException;
import com.HiBank.model.Card;
import com.HiBank.model.Client;
import com.HiBank.model.Role;
import com.HiBank.model.Users;
import com.HiBank.repository.CardRepo;
import com.HiBank.repository.ClientRepo;
import com.HiBank.repository.RoleRepo;
import com.HiBank.repository.UserRepo;
import com.github.javafaker.CreditCardType;
import com.github.javafaker.Faker;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class UserService
{
  @Autowired
  private UserRepo userRepo;
  @Autowired
  private ClientRepo clientRepo;
  @Autowired
  private CardRepo cardRepo;
  @Autowired
  private RoleRepo roleRepo;
  @Autowired
  private PasswordEncoder passwordEncoder;
  @Autowired
  private JwtService jwtService;
  @Autowired
  private RoleService roleService;

  public Users getUserById(Long id)
  {
    Users user = userRepo.findById(id).orElse(null);
    if (user == null)
    {
      log.error(String.format("User with id : %s does not exist", id));
      throw new ResourceNotFoundException(String.format("User with id : %s does not exist", id));
    }
    return user;
  }

  public List<Users> getAllUsers()
  {
    List<Users> users = userRepo.findAllByIsDeleted(false);
    log.info("fetched all the non-deleted users");
    return users;
  }

  public List<Users> getAllUsersByClientId(Long clientId)
  {
    List<Users> users = userRepo.findAllByClientIdAndIsDeleted(clientId, false);
    log.info("fetched all the non-deleted users by client id");
    return users;
  }

  public String getUserRole(String username)
  {
    Users user = userRepo.findByUserName(username);
    if (user == null)
    {
      log.error(String.format("User with the username : %s, not available", username));
      throw new ResourceNotFoundException(String.format("User with the username : %s, not available", username));
    }
    return user.getRole().getRole();
  }

  public LocalDateTime assignExpiryDate(LocalDateTime currentDate)
  {
    return currentDate.plusDays(2);
  }

  public Card generateCard(Users newUser)
  {
    try
    {
      Faker faker = new Faker();
      LocalDateTime localDateTime = LocalDateTime.now();
      Card card = Card.builder()
              .number(faker.finance().creditCard(CreditCardType.MASTERCARD))
              .isValid(true)
              .issuedDate(localDateTime)
              .validTill(assignExpiryDate(localDateTime))
              .user(newUser)
              .isReported(false)
              .build();
      cardRepo.save(card);
      log.info(String.format("Successfully generated a card for user : %s", newUser.getId()));
      return card;
    }
    catch (Exception e)
    {
      log.error("Error while creating the card for a user" + e.getMessage());
      throw new CardCreationException("Error while creating the card for a user");
    }
  }

  public void invalidateExistingCards(Users user)
  {
    List<Card> cards = user.getCard();
    log.info(String.format("Successfully fetched all the cards of user : %s", user.getId()));
    for (Card card : cards)
    {
      if (card.getIsValid() == true)
      {
        card.setIsValid(false);
        log.info(String.format("Successfully invalidated the card : %s", card.getId()));
      }
      cardRepo.save(card);
    }
  }

  public Users addUser(ClientUser user, boolean isPoc)
  {
    Role role = null;
    Client client = null;
    if (user.getRoleId() != null)
    {
      role = roleRepo.findById(user.getRoleId()).orElse(null);
    }
    else
    {
      role = roleRepo.findByRole("standard");
    }
    if (role == null)
    {
      log.error(String.format("Role with id : %s not found", user.getRoleId()));
      throw new ResourceNotFoundException(String.format("Role with id : %s not found", user.getRoleId()));
    }
    if (user.getClientId() != null)
    {
      client = clientRepo.findById(user.getClientId()).orElse(null);
      if (client == null)
      {
        log.error(String.format("Client with id : %s not found", user.getClientId()));
        throw new ResourceNotFoundException(String.format("Client with id : %s not found", user.getClientId()));
      }
    }
    Users newUser = Users.builder()
            .userName(user.getUsername())
            .password(passwordEncoder.encode(user.getPassword()))
            .role(role)
            .client(client)
            .isDeleted(false)
            .email(user.getEmail())
            .build();
    userRepo.save(newUser);
    log.info("Successfully saved the new user");
    List<Card> cards = new ArrayList<>();
    if (isPoc)
    {
      cards.add(generateCard(newUser));
      log.info(String.format("Generated a card for new user : %s", newUser.getId()));
    }
    newUser.setCard(cards);
    log.info("successfully saved card details of the new user");
    return newUser;
  }

  public Users registerAdmin(AdminLogin user) throws Exception
  {
    try
    {
      Users admin = Users.builder()
              .userName(user.getUserName())
              .password(passwordEncoder.encode(user.getPassword()))
              .role(roleService.getRoleByRoleName("admin"))
              .isDeleted(false)
              .email(user.getEmail())
              .build();
      return userRepo.save(admin);
    }
    catch (Exception e)
    {
      log.error("Error while creating admin user " + e.getMessage());
      throw new Exception("Error while creating admin user");
    }
  }

  public Users registerUser(ClientUser user, String authorizationHeader) throws Exception
  {
    Users newUser;
    String token = authorizationHeader.replace("Bearer ", "");
    Claims claims = jwtService.getClaims(token);
    log.info("Successfully fetched token and claims details");
    if (claims.get("id") == null)
    {
      if (getUserRole(jwtService.extractUsername(token)).equals("admin"))
      {
        log.info("admin user is registering a new user");
        newUser = addUser(user, false);
      }
      else
      {
        log.info(String.format("user don't have proper client information"));
        throw new BadRequestException("Invalid Client information");
      }
    }
    else
    {
      // have a look on this condition later
      if (!claims.get("id").toString().equals(user.getClientId().toString()) || roleService.getRole(user.getRoleId()).getRole().equals("admin"))
      {
        log.error("user don't have permission to register user from other client or admin user");
        throw new AccessDeniedException("Access Denied : User Do not have permission");
      }
      if (getUserRole(jwtService.extractUsername(token)).equals("poc") && roleService.getRole(user.getRoleId()).getRole().equals("poc"))
      {
        log.error("user don't have permission to poc user");
        throw new AccessDeniedException("Access Denied : User Do not have permission");
      }
      newUser = addUser(user, true);
    }
    log.info(String.format("Successfully register new user with username: %s and role id: %s", user.getUsername(), user.getRoleId()));
    return newUser;
  }

  public ResponseEntity<Users> assignRole(Long userId, Long roleId)
  {
    Role role = roleRepo.findById(roleId).orElse(null);
    if (role == null)
    {
      log.error(String.format("Role with id : %s does not exist", roleId));
      throw new ResourceNotFoundException(String.format("Role with id : %s does not exist", roleId));
    }
    Users user = userRepo.findById(userId).orElse(null);
    if (user == null)
    {
      log.error(String.format("User with id : %s does not exist", userId));
      throw new ResourceNotFoundException(String.format("User with id : %s does not exist", userId));
    }
    user.setRole(role);
    userRepo.save(user);
    log.info("role assigning done successfully ");
    return ResponseEntity.ok(userRepo.findById(userId).orElse(null));
  }

  public Users deleteUser(Long id, String authorizationHeader)
  {
    Users deletedUser = userRepo.findById(id).orElse(null);
    if (deletedUser == null)
    {
      log.error(String.format("User with id = %s does not exist", id));
      throw new ResourceNotFoundException(String.format("User with id = %s does not exist", id));
    }
    else
    {
      String token = authorizationHeader.replace("Bearer ", "");
      Claims claims = jwtService.getClaims(token);
      log.info("Successfully fetched token and claim details");
      if (claims.get("id") == null)
      {
        if (!getUserRole(jwtService.extractUsername(token)).equals("admin"))
        {
          log.info(String.format("User %s not associated with any client", id));
          throw new BadRequestException("User not associated with any client");
        }
      }
      else
      {
        if (getUserById(id).getRole().getRole().equals("admin") || !claims.get("id").toString().equals(getUserById(id).getClient().getId().toString()) )
        {
          log.info("User trying to delete either a admin or user from another client");
          throw new AccessDeniedException("Access Denied : User Do not have permission");
        }
      }
      invalidateExistingCards(deletedUser);
      deletedUser.setIsDeleted(true);
      userRepo.save(deletedUser);
      log.info("Soft deleted and Invalidate all the user related cards");
    }
    return deletedUser;
  }
}
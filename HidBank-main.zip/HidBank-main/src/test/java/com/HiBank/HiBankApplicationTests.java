package com.HiBank;

import com.HiBank.controller.ClientControllerTest;
import com.HiBank.repository.*;
import com.HiBank.service.ClientServiceTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.springframework.boot.test.context.SpringBootTest;

@RunWith(Suite.class)
@SpringBootTest
@Suite.SuiteClasses({
        ClientRepoTest.class,
        ClientControllerTest.class,
        ClientServiceTest.class,
        CardRepoTest.class,
        RoleRepoTest.class,
        UserRepoTest.class})
class HiBankApplicationTests
{
}

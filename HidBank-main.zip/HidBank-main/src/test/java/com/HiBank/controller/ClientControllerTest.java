package com.HiBank.controller;

import com.HiBank.model.Client;
import com.HiBank.service.ClientService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class ClientControllerTest
{
  @Mock
  private ClientService clientService;

  @InjectMocks
  private ClientController clientController;

  private Client client1, client2;
  @Before
  public void setup()
  {
    client1 = new Client();
    client1.setId(1L);
    client1.setName("Test Client");
    client1.setIsDeleted(0);
    client1.setUser(null);

    // create a new
    client2 = new Client();
    client2.setId(1L);
    client2.setName("Test Client");
    client2.setIsDeleted(0);
    client2.setUser(null);
  }

  @Test
  public void test_create_client() throws Exception
  {

    Mockito.when(clientService.addClient(Mockito.any(Client.class))).thenReturn(client1);

    HttpEntity<Client> request = new HttpEntity<>(client1);
    ResponseEntity<Client> response = clientController.addClient(request.getBody());

    Assert.assertEquals(HttpStatus.OK, response.getStatusCode());

    Assert.assertEquals(client1, response.getBody());
  }

  @Test
  public void test_get_clients() throws Exception
  {
    List<Client> clients = new ArrayList<>();
    clients.add(client1);
    clients.add(client2);
    Mockito.when(clientService.getAllClients()).thenReturn(clients);

    ResponseEntity<List<Client>> response = clientController.getClients();

    Assert.assertEquals(HttpStatus.OK, response.getStatusCode());

    Assert.assertEquals(clients, response.getBody());
  }
}
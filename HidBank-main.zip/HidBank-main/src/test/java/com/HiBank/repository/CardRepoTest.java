package com.HiBank.repository;

import com.HiBank.model.Card;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;
import java.util.List;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class CardRepoTest
{
  @Autowired
  private CardRepo  cardRepo;

  @Autowired
  private TestEntityManager entityManager;

  private Card card, card1;

  @Before
  public void setup()
  {
    card = new Card();
    card.setNumber("xxxx-xxxx-xxxx-xxxx");
    card.setUser(null);
    card.setCardTransactions(null);
    card.setIsReported(true);
    card.setIsValid(false);
    card.setIssuedDate(LocalDateTime.now());
    card.setValidTill(LocalDateTime.now());
    entityManager.persist(card);
    entityManager.flush();

    card1 = new Card();
    card1.setNumber("xxxx-xxxx-yyyy-xxxx");
    card1.setUser(null);
    card1.setCardTransactions(null);
    card1.setIsReported(false);
    card1.setIsValid(false);
    card1.setIssuedDate(LocalDateTime.now());
    card1.setValidTill(LocalDateTime.now());
    entityManager.persist(card1);
    entityManager.flush();
  }

  @Test
  public void test_find_by_id_and_isValid()
  {
    Card searchedCards = cardRepo.findByIdAndIsValid((Long) entityManager.getId(card), false);
    Assert.assertEquals(card.getNumber(), searchedCards.getNumber());
    Assert.assertEquals(card.getIsValid(), searchedCards.getIsValid());
    Assert.assertEquals(card.getCardTransactions(), searchedCards.getCardTransactions());
    Assert.assertEquals(card.getUser(), searchedCards.getUser());
    Assert.assertEquals(card.getValidTill(), searchedCards.getValidTill());
    Assert.assertEquals(card.getIssuedDate(), searchedCards.getIssuedDate());
    Assert.assertEquals(card.getIsReported(), searchedCards.getIsReported());
  }

  @Test
  public void test_find_by_isValid_and_isReported()
  {
    List<Card> searchedCards = cardRepo.findAllByIsValidAndIsReported(false, false);
    Assert.assertEquals(1, searchedCards.size());
  }
}
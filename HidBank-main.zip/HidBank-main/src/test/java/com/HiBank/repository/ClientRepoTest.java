package com.HiBank.repository;

import com.HiBank.model.Client;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.List;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class ClientRepoTest
{
  @Autowired
  private ClientRepo  clientRepo;

  @Autowired
  private TestEntityManager entityManager;

  public Client client1, client2;

  @Before
  public void setup()
  {
    client1 = new Client();
    client1.setName("test1");
    client1.setIsDeleted(0);
    client1.setUser(null);
    entityManager.persist(client1);
    entityManager.flush();

    client2 = new Client();
    client2.setName("test2");
    client2.setIsDeleted(1);
    client2.setUser(null);
    entityManager.persist(client2);
    entityManager.flush();
  }

  @Test
  public void test_save_client()
  {
    Client client = clientRepo.save(client1);
    Assert.assertEquals(client1.getId(), client.getId());
    Assert.assertEquals(client1.getName(), client.getName());
    Assert.assertEquals(client1.getIsDeleted(), client.getIsDeleted());
    Assert.assertEquals(client1.getUser(), client.getUser());
  }

  @Test
  public void test_finding_All_By_IsDeleted()
  {
    List<Client> clients = clientRepo.findByIsDeletedEquals(1);
    Assert.assertEquals(1, clients.size());
  }
}

package com.HiBank.repository;

import com.HiBank.model.Role;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class RoleRepoTest
{
  @Autowired
  private RoleRepo roleRepo;

  @Autowired
  private TestEntityManager entityManager;

  private Role role;

  @Before
  public void setup()
  {
    role = new Role();
    role.setRole("admin");
    entityManager.persist(role);
    entityManager.flush();
  }

  @Test
  public void test_find_by_role()
  {
    Role searchedRole = roleRepo.findByRole("admin");
    Assert.assertEquals(entityManager.getId(role).toString(), searchedRole.getId().toString());
    Assert.assertEquals("admin", searchedRole.getRole());
  }
}
package com.HiBank.repository;

import com.HiBank.model.Client;
import com.HiBank.model.Role;
import com.HiBank.model.Users;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;


@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class UserRepoTest
{
  @Autowired
  private UserRepo userRepo;

  @Autowired
  private TestEntityManager entityManager;

  private Users user1, user2;
  private Client client;

  @Before
  public void setup()
  {
    client = new Client();
    client.setName("infosys");
    entityManager.persist(client);
    entityManager.flush();

    Role role = new Role();
    role.setRole("admin");
    entityManager.persist(role);
    entityManager.flush();

    Role role2 = new Role();
    role2.setRole("poc");
    entityManager.persist(role2);
    entityManager.flush();

    user1 = new Users();
    user1.setRole(role);
    user1.setUserName("admin");
    user1.setPassword("password");
    user1.setClient(client);
    user1.setEmail("admin@mail.com");
    user1.setIsDeleted(true);
    entityManager.persist(user1);
    entityManager.flush();

    user2 = new Users();
    user2.setRole(role2);
    user2.setClient(client);
    user2.setUserName("poc");
    user2.setPassword("password");
    user2.setEmail("poc@mail.com");
    user2.setIsDeleted(false);
    entityManager.persist(user2);
    entityManager.flush();
  }

  @Test
  public void test_find_admin_emails()
  {
    List<String> emails = userRepo.findAdminEmails();
    Assert.assertEquals(1, emails.size());
    Assert.assertEquals("admin@mail.com", emails.get(0));
  }

  @Test
  public void test_find_by_username()
  {
    Users user = userRepo.findByUserName("admin");
    Assert.assertEquals("password", user.getPassword());
    Assert.assertEquals("admin@mail.com", user.getEmail());
    Assert.assertEquals("admin", user.getUsername());
    Assert.assertEquals(entityManager.getId(user1).toString(), user.getId().toString());
  }

  @Test
  public void test_find_all_by_is_deleted()
  {
    List<Users> user = userRepo.findAllByIsDeleted(true);
    Assert.assertEquals(1, user.size());
    Assert.assertEquals("admin", user.get(0).getUsername());
  }

  @Test
  public void test_find_All_By_Client_Id_And_IsDeleted()
  {
    List<Users> user = userRepo.findAllByClientIdAndIsDeleted((Long) entityManager.getId(client), false);
    Assert.assertEquals(1, user.size());
    Assert.assertEquals("poc", user.get(0).getUsername());
  }

  @Test
  public void test_find_Email_Id_Of_Client_Poc()
  {
    List<Object[]> ClientUser = userRepo.findEmailIdOfClientPoc();
    Assert.assertEquals((Long) entityManager.getId(client),(Long)  ClientUser.get(0)[0]);
    Assert.assertEquals(client.getName(), ClientUser.get(0)[1].toString());
    Assert.assertEquals(user2.getEmail(), ClientUser.get(0)[2].toString());
  }
}
package com.HiBank.service;

import com.HiBank.model.Card;
import com.HiBank.model.Users;
import com.HiBank.repository.CardRepoTest;
import com.HiBank.repository.UserRepo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class CardServiceTest
{
  @InjectMocks
  private CardService cardService;

  @Mock
  private UserService userService;

  @Mock
  private CardRepoTest cardRepo;
  @Mock
  private UserRepo userRepo;
  private Card card1, card2;
  private Users user;

  @Before
  public void setup()
  {
    card1 = new Card();
    card1.setId(1L);
    card1.setIsValid(true);
    card1.setIsReported(false);
    card1.setNumber("xxxx-xxxx-xxxx-xxxx");
    card1.setCardTransactions(null);
    card1.setUser(null);

    card2 = new Card();
    card2.setId(1L);
    card2.setIsValid(true);
    card2.setIsReported(false);
    card2.setNumber("xxxx-xxxx-yyyy-xxxx");
    card2.setCardTransactions(null);
    card2.setUser(null);

    List<Card> cards = new ArrayList<>();
    cards.add(card2);
    user = new Users();
    user.setId(1L);
    user.setCard(cards);
  }

  @Test
  public void test_assign_new_card()
  {
//    Mockito.when(userRepo.findById(Mockito.any())).thenReturn(Optional.ofNullable(user));
//    Mockito.when(cardRepo.save(card1)).thenReturn(card1);
//    Mockito.when(userRepo.save(user)).thenReturn(user);
//    Users user = cardService.assignNewCard(1L);
  }
}

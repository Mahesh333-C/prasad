package com.HiBank.service;

import com.HiBank.dto.TransactionDetails;
import com.HiBank.exception.BadRequestException;
import com.HiBank.repository.CardRepo;
import com.HiBank.repository.CardRepoTest;
import com.HiBank.repository.CardTransactionRepo;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class CardTransactionServiceTest
{
  @InjectMocks
  private CardTransactionService cardTransactionService;

  @Mock
  private CardTransactionRepo cardTransactionRepo;
  @Mock
  private CardRepo cardRepo;
  private TransactionDetails transactionDetails;

  @Before
  public void setup()
  {
    transactionDetails = new TransactionDetails();
    transactionDetails.setCardId(1L);
  }

  @Test
  public void test_uploading_transaction_for_non_existing_card()
  {
    Mockito.when(cardRepo.findByIdAndIsValid(transactionDetails.getCardId(), Mockito.any())).thenReturn(null);
    Assert.assertThrows(BadRequestException.class, () -> {
      cardTransactionService.uploadTransaction(Mockito.any(), Mockito.anyString());
    });
  }
}

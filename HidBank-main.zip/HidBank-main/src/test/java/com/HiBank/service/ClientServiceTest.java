package com.HiBank.service;

import com.HiBank.exception.ResourceNotFoundException;
import com.HiBank.model.Client;
import com.HiBank.repository.ClientRepo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RunWith(MockitoJUnitRunner.class)
public class ClientServiceTest
{
  @InjectMocks
  private ClientService clientService;

  @Mock
  private ClientRepo clientRepo;
  private Client client1, client2;

  @Before
  public void setup()
  {
    client1 = new Client();
    client1.setId(1L);
    client1.setName("Test Client1");
    client1.setIsDeleted(0);
    client1.setUser(null);

    client2 = new Client();
    client2.setId(2L);
    client2.setName("Test Client2");
    client2.setIsDeleted(0);
    client2.setUser(null);
  }

  @Test
  public void test_get_all_client()
  {
    List<Client> clients = new ArrayList<>();
    clients.add(client1);
    clients.add(client2);
    Mockito.when(clientRepo.findByIsDeletedEquals(0)).thenReturn(clients);
    List<Client> allClients = clientService.getAllClients();
    Assert.assertNotEquals(null, allClients);
    Assert.assertTrue(allClients.size() > 1);
  }

  @Test
  public void test_update_a_client()
  {
    Mockito.when(clientRepo.findById(Mockito.any())).thenReturn(Optional.ofNullable(client1));
    Mockito.when(clientRepo.save(Mockito.any(Client.class))).thenReturn(client1);
    Client newClient = clientService.updateClient(client1);
    Assert.assertNotEquals(null, newClient);
    Assert.assertNotNull(newClient.getId());
    Assert.assertEquals(client1.getName(), newClient.getName());
    Assert.assertEquals(client1.getIsDeleted(), newClient.getIsDeleted());
    Assert.assertEquals(null, newClient.getUser());
  }

  @Test
  public void test_update_non_existing_client()
  {
    Mockito.when(clientRepo.findById(Mockito.any())).thenReturn(null);
    Assert.assertThrows(ResourceNotFoundException.class, () -> {
      clientService.updateClient(client1);
    });
  }

  @Test
  public void test_delete_a_client()
  {
    Mockito.when(clientRepo.findById(Mockito.any())).thenReturn(Optional.ofNullable(client1));
    Mockito.when(clientRepo.save(Mockito.any(Client.class))).thenReturn(client1);
    Client newClient = clientService.deleteClient(1L);
    Assert.assertNotEquals(null, newClient);
    Assert.assertNotNull(newClient.getId());
    Assert.assertEquals(client1.getName(), newClient.getName());
    Assert.assertEquals(client1.getIsDeleted(), 1);
    Assert.assertEquals(null, newClient.getUser());
  }
}
